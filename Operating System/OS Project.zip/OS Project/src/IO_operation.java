import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class IO_operation {
    public static void showIOOperations(JFrame frame) {
        frame.setVisible(false);
        JFrame ioFrame = new JFrame("I/O Operations");
        ioFrame.setSize(800, 600);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(2, 1, 10, 10));

        JLabel ioLabel = new JLabel("Nothing", SwingConstants.CENTER);
        ioLabel.setFont(new Font("Arial", Font.BOLD, 24));

        JButton backButton = createButton("Back");
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ioFrame.dispose();
                frame.setVisible(true);
            }
        });

        panel.add(ioLabel);
        panel.add(backButton);

        ioFrame.add(panel);
        ioFrame.setVisible(true);
    }

    private static JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setPreferredSize(new Dimension(200, 40));
        return button;
    }
}

import javax.swing.*;
import java.awt.*;

public class PCBOperations {

    static String[] processNames = {"Process1", "Process2", "Process3"};
    static String[] processStatuses = {"Running", "Suspended", "Blocked"};
    static String[] processPriorities = {"High", "Low", "Medium"};
    static int[] processIDs = {1, 2, 3};
    static String[] processOwners = {"Owner1", "Owner2", "Owner3"};
    static int[] parentIDs = {0, 1, 1};
    static int[][] childIDs = {{1}, {2, 3}, {}};
    static String[] memoryRequirements = {"256MB", "512MB", "1GB"};
    static String[] allocatedMemory = {"0x0001", "0x0010", "0x0100"};
    static String[] cpuRegisters = {"EAX:0", "EBX:1", "ECX:2"};
    static String[] processors = {"CPU1", "CPU2", "CPU3"};
    static String[] ioState = {"Idle", "Busy", "Idle"};

    public static void showPCBOperations(JFrame frame) {
        frame.setVisible(false);

        JFrame pcbFrame = new JFrame("Process Control Block (PCB)");
        pcbFrame.setSize(900, 700);
        pcbFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        pcbFrame.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout(10, 10));
        panel.setBackground(new Color(45, 45, 45));

        JLabel pcbLabel = new JLabel("Process Control Block (PCB)", SwingConstants.CENTER);
        pcbLabel.setFont(new Font("Segoe UI", Font.BOLD, 30));
        pcbLabel.setForeground(new Color(255, 215, 0));
        pcbLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(11, 1, 10, 10));
        buttonPanel.setBackground(new Color(60, 63, 65));

        String[] buttonNames = {
                "Unique Identification of the Process",
                "Current State of the Process",
                "Owner of the Process",
                "Process’s Priority",
                "Pointer to the Process Parent",
                "Pointers to Process’s Child Processes",
                "Memory Requirements",
                "Pointer to Allocated Memory",
                "The Register Save Area – CPU Register",
                "The Processor It Is Running On",
                "I/O State Information"
        };

        for (int i = 0; i < buttonNames.length; i++) {
            final int index = i;
            JButton button = createButton(buttonNames[i]);
            button.addActionListener(e -> handleButtonClick(index));
            buttonPanel.add(button);
        }

        JButton backButton = createButton("Back to Main Menu");
        backButton.setBackground(new Color(255, 69, 58));
        backButton.addActionListener(e -> {
            pcbFrame.dispose();
            frame.setVisible(true);
        });

        panel.add(pcbLabel, BorderLayout.NORTH);
        panel.add(buttonPanel, BorderLayout.CENTER);
        panel.add(backButton, BorderLayout.SOUTH);

        pcbFrame.add(panel);
        pcbFrame.setVisible(true);
    }

    private static void handleButtonClick(int option) {
        String message = "";
        switch (option) {
            case 0:
                message = getProcessInfo("ID");
                break;
            case 1:
                message = getProcessInfo("Status");
                break;
            case 2:
                message = getProcessInfo("Owner");
                break;
            case 3:
                message = getProcessInfo("Priority");
                break;
            case 4:
                message = getProcessInfo("ParentID");
                break;
            case 5:
                message = getProcessInfo("ChildIDs");
                break;
            case 6:
                message = getProcessInfo("MemoryRequirements");
                break;
            case 7:
                message = getProcessInfo("AllocatedMemory");
                break;
            case 8:
                message = getProcessInfo("CPURegister");
                break;
            case 9:
                message = getProcessInfo("Processor");
                break;
            case 10:
                message = getProcessInfo("IOState");
                break;
            default:
                message = "Invalid Option";
        }
        JOptionPane.showMessageDialog(null, message, "Process Information", JOptionPane.INFORMATION_MESSAGE);
    }

    private static String getProcessInfo(String type) {
        StringBuilder processInfo = new StringBuilder();

        for (int i = 0; i < processNames.length; i++) {
            switch (type) {
                case "ID":
                    processInfo.append("ID: ").append(processIDs[i]).append("\n");
                    break;
                case "Status":
                    processInfo.append("Status: ").append(processStatuses[i]).append("\n");
                    break;
                case "Owner":
                    processInfo.append("Owner: ").append(processOwners[i]).append("\n");
                    break;
                case "Priority":
                    processInfo.append("Priority: ").append(processPriorities[i]).append("\n");
                    break;
                case "ParentID":
                    processInfo.append("Parent ID: ").append(parentIDs[i]).append("\n");
                    break;
                case "ChildIDs":
                    processInfo.append("Child IDs: ").append(java.util.Arrays.toString(childIDs[i])).append("\n");
                    break;
                case "MemoryRequirements":
                    processInfo.append("Memory Requirements: ").append(memoryRequirements[i]).append("\n");
                    break;
                case "AllocatedMemory":
                    processInfo.append("Allocated Memory: ").append(allocatedMemory[i]).append("\n");
                    break;
                case "CPURegister":
                    processInfo.append("CPU Register: ").append(cpuRegisters[i]).append("\n");
                    break;
                case "Processor":
                    processInfo.append("Processor: ").append(processors[i]).append("\n");
                    break;
                case "IOState":
                    processInfo.append("I/O State: ").append(ioState[i]).append("\n");
                    break;
            }
            processInfo.append("============================================\n");
        }

        return processInfo.toString();
    }

    private static JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setPreferredSize(new Dimension(300, 50));
        button.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        button.setBackground(new Color(100, 149, 237));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createLineBorder(new Color(70, 130, 180), 2));
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(135, 206, 250));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(100, 149, 237));
            }
        });
        return button;
    }
}

class Process
{
    String Id;
    int pid;
    String name;
    int AT; // Arrival Time
    int BT; // Burst Time
    String status;
    String priority;

    public Process(int pid, String name, int AT, int BT) {
        this.pid = pid;
        this.name = name;
        this.AT = AT;
        this.BT = BT;
        this.status = "ready";
        this.priority = "high";
    }

    public void dispatch() {
        this.status = "running";
    }

    public void changePriority(String newPriority) {
        this.priority = newPriority;
    }

    public void communicate(Process otherProcess, String message) {
        System.out.println("Process " + this.name + " sent message to " + otherProcess.name + ": " + message);
    }
}

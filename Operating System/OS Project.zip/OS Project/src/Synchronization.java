import javax.swing.*;
import java.awt.*;
import java.util.concurrent.Semaphore;
import java.util.LinkedList;
import java.util.Queue;
import java.io.*;
import java.net.*;

public class Synchronization {

    public static void showSynchronizationAndIPC(JFrame frame) {
        JFrame syncFrame = new JFrame("Synchronization & IPC");
        syncFrame.setSize(800, 600);
        syncFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(4, 1, 10, 10));

        JButton syncButton = createButton("Synchronization (Semaphore)");
        syncButton.addActionListener(e -> showSynchronization());

        JButton ipcSocketButton = createButton("IPC via Sockets");
        ipcSocketButton.addActionListener(e -> ipcUsingSockets());

        JButton ipcMessagePassingButton = createButton("IPC via Message Passing");
        ipcMessagePassingButton.addActionListener(e -> ipcUsingMessagePassing());

        JButton ipcSharedMemoryButton = createButton("IPC via Shared Memory");
        ipcSharedMemoryButton.addActionListener(e -> ipcUsingSharedMemory());

        panel.add(syncButton);
        panel.add(ipcSocketButton);
        panel.add(ipcMessagePassingButton);
        panel.add(ipcSharedMemoryButton);

        syncFrame.add(panel);
        syncFrame.setVisible(true);
    }

    private static void showSynchronization() {
        JFrame syncFrame = new JFrame("Synchronization (Semaphore)");
        syncFrame.setSize(600, 400);

        JTextArea logArea = new JTextArea();
        logArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(logArea);

        JButton startButton = createButton("Start Resource Sharing");
        startButton.addActionListener(e -> {
            logArea.setText("");
            Semaphore semaphore = new Semaphore(1);
            Thread t1 = new Thread(() -> accessCriticalSection("Thread-1", semaphore, logArea));
            Thread t2 = new Thread(() -> accessCriticalSection("Thread-2", semaphore, logArea));
            t1.start();
            t2.start();
        });

        syncFrame.setLayout(new BorderLayout());
        syncFrame.add(scrollPane, BorderLayout.CENTER);
        syncFrame.add(startButton, BorderLayout.SOUTH);
        syncFrame.setVisible(true);
    }

    private static void accessCriticalSection(String threadName, Semaphore semaphore, JTextArea logArea) {
        try {
            logArea.append(threadName + " is waiting to access the critical section...\n");
            semaphore.acquire();
            logArea.append(threadName + " has entered the critical section.\n");
            Thread.sleep(2000); // Simulate work in the critical section
            logArea.append(threadName + " is leaving the critical section.\n");
        } catch (InterruptedException e) {
            logArea.append(threadName + " was interrupted.\n");
        } finally {
            semaphore.release();
        }
    }

    // Task-4.2: Inter-Process Communication (IPC) using Sockets
    private static void ipcUsingSockets() {
        JFrame socketFrame = new JFrame("IPC via Sockets");
        socketFrame.setSize(600, 400);

        JTextArea logArea = new JTextArea();
        logArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(logArea);

        JButton startButton = createButton("Start Socket Communication");
        startButton.addActionListener(e -> {
            logArea.setText("");
            new Thread(() -> startServer(logArea)).start();
            new Thread(() -> startClient(logArea)).start();
        });

        socketFrame.setLayout(new BorderLayout());
        socketFrame.add(scrollPane, BorderLayout.CENTER);
        socketFrame.add(startButton, BorderLayout.SOUTH);
        socketFrame.setVisible(true);
    }

    private static void startServer(JTextArea logArea) {
        try (ServerSocket serverSocket = new ServerSocket(12345)) {
            logArea.append("Server started, waiting for client...\n");
            Socket socket = serverSocket.accept();
            logArea.append("Client connected.\n");
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            out.println("Hello from Server!");
            socket.close();
        } catch (IOException e) {
            logArea.append("Server error: " + e.getMessage() + "\n");
        }
    }

    private static void startClient(JTextArea logArea) {
        try (Socket socket = new Socket("localhost", 12345)) {
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String message = in.readLine();
            logArea.append("Client received: " + message + "\n");
        } catch (IOException e) {
            logArea.append("Client error: " + e.getMessage() + "\n");
        }
    }

    private static void ipcUsingMessagePassing() {
        JFrame messageFrame = new JFrame("IPC via Message Passing");
        messageFrame.setSize(600, 400);

        JTextArea logArea = new JTextArea();
        logArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(logArea);

        JButton startButton = createButton("Start Message Passing");
        startButton.addActionListener(e -> {
            logArea.setText("");
            Queue<String> messageQueue = new LinkedList<>();
            Thread producer = new Thread(() -> produceMessages(messageQueue, logArea));
            Thread consumer = new Thread(() -> consumeMessages(messageQueue, logArea));
            producer.start();
            consumer.start();
        });

        messageFrame.setLayout(new BorderLayout());
        messageFrame.add(scrollPane, BorderLayout.CENTER);
        messageFrame.add(startButton, BorderLayout.SOUTH);
        messageFrame.setVisible(true);
    }

    private static void produceMessages(Queue<String> queue, JTextArea logArea) {
        for (int i = 1; i <= 5; i++) {
            synchronized (queue) {
                String message = "Message " + i;
                queue.add(message);
                logArea.append("Produced: " + message + "\n");
                queue.notify();
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                logArea.append("Producer interrupted.\n");
            }
        }
    }

    private static void consumeMessages(Queue<String> queue, JTextArea logArea) {
        for (int i = 1; i <= 5; i++) {
            synchronized (queue) {
                while (queue.isEmpty()) {
                    try {
                        queue.wait();
                    } catch (InterruptedException e) {
                        logArea.append("Consumer interrupted.\n");
                    }
                }
                String message = queue.poll();
                logArea.append("Consumed: " + message + "\n");
            }
        }
    }

    private static void ipcUsingSharedMemory() {
        JFrame sharedFrame = new JFrame("IPC via Shared Memory");
        sharedFrame.setSize(600, 400);

        JTextArea logArea = new JTextArea();
        logArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(logArea);

        JButton startButton = createButton("Start Shared Memory IPC");
        startButton.addActionListener(e -> {
            logArea.setText("");
            SharedMemory sharedMemory = new SharedMemory();
            Thread writer = new Thread(() -> writeToSharedMemory(sharedMemory, logArea));
            Thread reader = new Thread(() -> readFromSharedMemory(sharedMemory, logArea));
            writer.start();
            reader.start();
        });

        sharedFrame.setLayout(new BorderLayout());
        sharedFrame.add(scrollPane, BorderLayout.CENTER);
        sharedFrame.add(startButton, BorderLayout.SOUTH);
        sharedFrame.setVisible(true);
    }

    private static void writeToSharedMemory(SharedMemory sharedMemory, JTextArea logArea) {
        for (int i = 1; i <= 5; i++) {
            synchronized (sharedMemory) {
                sharedMemory.data = "Data " + i;
                logArea.append("Written to shared memory: " + sharedMemory.data + "\n");
                sharedMemory.notify();
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                logArea.append("Writer interrupted.\n");
            }
        }
    }

    private static void readFromSharedMemory(SharedMemory sharedMemory, JTextArea logArea) {
        for (int i = 1; i <= 5; i++) {
            synchronized (sharedMemory) {
                while (sharedMemory.data == null) {
                    try {
                        sharedMemory.wait();
                    } catch (InterruptedException e) {
                        logArea.append("Reader interrupted.\n");
                    }
                }
                logArea.append("Read from shared memory: " + sharedMemory.data + "\n");
                sharedMemory.data = null;
            }
        }
    }

    private static JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setPreferredSize(new Dimension(200, 40));
        return button;
    }

    static class SharedMemory {
        String data;
    }
}

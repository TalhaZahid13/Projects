import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MemoryManagement {
    public static void showMemoryManagement(JFrame frame) {
        JFrame memoryFrame = new JFrame("Memory Management");
        memoryFrame.setSize(800, 600);

        JPanel memoryPanel = new JPanel();
        memoryPanel.setLayout(new GridLayout(3, 1, 10, 10));

        JButton pagingButton = createButton("Paging");
        pagingButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showPaging(memoryFrame);
            }
        });

        JButton lruButton = createButton("LRU");
        lruButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showLRU(memoryFrame);
            }
        });

        JButton backButton = createButton("Back");
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                memoryFrame.dispose();
                frame.setVisible(true);
            }
        });

        memoryPanel.add(pagingButton);
        memoryPanel.add(lruButton);
        memoryPanel.add(backButton);

        memoryFrame.add(memoryPanel);
        memoryFrame.setVisible(true);
    }

    private static void showPaging(JFrame frame) {
        frame.setVisible(false);
        JFrame pagingFrame = new JFrame("Paging");
        pagingFrame.setSize(800, 600);

        JPanel panel = new JPanel(new GridLayout(10, 2, 10, 10));

        JTextField msField = new JTextField();
        JTextField psField = new JTextField();
        JTextField npField = new JTextField();
        JTextField xField = new JTextField();
        JTextField yField = new JTextField();
        JTextField offsetField = new JTextField();

        panel.add(new JLabel("Enter memory size:"));
        panel.add(msField);
        panel.add(new JLabel("Enter page size:"));
        panel.add(psField);
        panel.add(new JLabel("Enter number of processes:"));
        panel.add(npField);
        panel.add(new JLabel("Enter process no., page no., and offset to find physical address:"));
        panel.add(xField);
        panel.add(yField);
        panel.add(offsetField);

        JButton findButton = createButton("Find Physical Address");
        findButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int ms = Integer.parseInt(msField.getText());
                int ps = Integer.parseInt(psField.getText());
                int np = Integer.parseInt(npField.getText());
                int x = Integer.parseInt(xField.getText());
                int y = Integer.parseInt(yField.getText());
                int offset = Integer.parseInt(offsetField.getText());

                int nop = ms / ps;
                int[] s = new int[np + 1];
                int[][] fno = new int[np + 1][100];
                int rempages = nop;

                for (int i = 1; i <= np; i++) {
                    String noOfPages = JOptionPane.showInputDialog("Enter number of pages required for process " + i + ":");
                    s[i] = Integer.parseInt(noOfPages);
                    if (s[i] > rempages) {
                        JOptionPane.showMessageDialog(pagingFrame, "Memory is full");
                        return;
                    }
                    rempages -= s[i];
                    for (int j = 0; j < s[i]; j++) {
                        String pageTableEntry = JOptionPane.showInputDialog("Enter page table entry for process " + i + " page " + j + ":");
                        fno[i][j] = Integer.parseInt(pageTableEntry);
                    }
                }

                if (x > np || y >= s[x] || offset >= ps) {
                    JOptionPane.showMessageDialog(pagingFrame, "Invalid process number, page number, or offset");
                } else {
                    int pa = fno[x][y] * ps + offset;
                    JOptionPane.showMessageDialog(pagingFrame, "The physical address is: " + pa);
                }
            }
        });

        JButton backButton = createButton("Back");
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                pagingFrame.dispose();
                frame.setVisible(true);
            }
        });

        panel.add(findButton);
        panel.add(backButton);

        pagingFrame.add(panel);
        pagingFrame.setVisible(true);
    }

    private static void showLRU(JFrame frame) {
        frame.setVisible(false);
        JFrame lruFrame = new JFrame("LRU");
        lruFrame.setSize(800, 600);

        JPanel panel = new JPanel(new GridLayout(10, 2, 10, 10));

        JTextField nopagesField = new JTextField();
        JTextField nofaultsField = new JTextField();

        panel.add(new JLabel("Enter number of pages:"));
        panel.add(nopagesField);
        panel.add(new JLabel("Enter reference string (comma separated):"));
        panel.add(new JTextField());
        panel.add(new JLabel("Enter number of frames:"));
        panel.add(nofaultsField);

        JButton calculateButton = createButton("Calculate Page Faults");
        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int nopages = Integer.parseInt(nopagesField.getText());
                int[] page = new int[nopages];

                String referenceString = JOptionPane.showInputDialog("Enter reference string (comma separated):");
                String[] refStrArray = referenceString.split(",");
                for (int i = 0; i < nopages; i++) {
                    page[i] = Integer.parseInt(refStrArray[i]);
                }

                int nofaults = Integer.parseInt(nofaultsField.getText());
                int[] frame = new int[nofaults];
                int[] fcount = new int[nofaults];

                for (int i = 0; i < nofaults; i++) {
                    frame[i] = -1;
                    fcount[i] = 0;
                }

                int count = 0;
                for (int i = 0; i < nopages; i++) {
                    int flag = 0;
                    for (int j = 0; j < nofaults; j++) {
                        if (page[i] == frame[j]) {
                            flag = 1;
                            fcount[j] = i + 1;
                        }
                    }
                    if (flag == 0) {
                        int min = 0;
                        for (int k = 0; k < nofaults - 1; k++) {
                            if (fcount[min] > fcount[k + 1]) {
                                min = k + 1;
                            }
                        }
                        frame[min] = page[i];
                        fcount[min] = i + 1;
                        count++;
                    }
                }

                JOptionPane.showMessageDialog(lruFrame, "Page Faults: " + count);
            }
        });

        JButton backButton = createButton("Back");
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                lruFrame.dispose();
                frame.setVisible(true);
            }
        });

        panel.add(calculateButton);
        panel.add(backButton);

        lruFrame.add(panel);
        lruFrame.setVisible(true);
    }

    private static JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setPreferredSize(new Dimension(200, 40));
        return button;
    }
}

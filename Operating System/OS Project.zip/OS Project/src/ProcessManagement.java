import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
public class ProcessManagement
{
    private static int total = 0;
    private static ArrayList<Process> processes = new ArrayList<>();
    private static JTable processTable;
    private static DefaultTableModel model;
    public static void showProcessManagement(JFrame frame)
    {
        JFrame processFrame = new JFrame("Advanced Process Management");
        processFrame.setSize(1000, 700);
        processFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        mainPanel.setBackground(new Color(45, 45, 45));
        model = new DefaultTableModel(new String[]{"PID", "Name", "AT", "BT", "Status", "Priority"}, 0);
        processTable = new JTable(model);
        processTable.setRowHeight(25);
        processTable.setFont(new Font("SansSerif", Font.PLAIN, 14));
        processTable.setBackground(new Color(60, 63, 65));
        processTable.setForeground(Color.WHITE);
        processTable.setGridColor(new Color(75, 75, 75));
        processTable.getTableHeader().setBackground(new Color(30, 30, 30));
        processTable.getTableHeader().setForeground(Color.WHITE);
        JScrollPane tableScrollPane = new JScrollPane(processTable);
        JLabel tableTitle = new JLabel("Process Table", SwingConstants.CENTER);
        tableTitle.setFont(new Font("SansSerif", Font.BOLD, 16));
        tableTitle.setForeground(Color.WHITE);
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(new Color(45, 45, 45));
        tablePanel.add(tableTitle, BorderLayout.NORTH);
        tablePanel.add(tableScrollPane, BorderLayout.CENTER);
        JPanel inputPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        inputPanel.setBackground(new Color(45, 45, 45));
        JTextField nameField = new JTextField();
        JTextField atField = new JTextField();
        JTextField btField = new JTextField();
        nameField.setBackground(new Color(60, 63, 65));
        nameField.setForeground(Color.WHITE);
        nameField.setCaretColor(Color.WHITE);
        atField.setBackground(new Color(60, 63, 65));
        atField.setForeground(Color.WHITE);
        atField.setCaretColor(Color.WHITE);
        btField.setBackground(new Color(60, 63, 65));
        btField.setForeground(Color.WHITE);
        btField.setCaretColor(Color.WHITE);
        inputPanel.add(createStyledLabel("Process Name:"));
        inputPanel.add(nameField);
        inputPanel.add(createStyledLabel("Arrival Time:"));
        inputPanel.add(atField);
        inputPanel.add(createStyledLabel("Burst Time:"));
        inputPanel.add(btField);
        JPanel buttonPanel = new JPanel(new GridLayout(3, 3, 10, 10));
        buttonPanel.setBackground(new Color(45, 45, 45));
        JButton createButton = createStyledButton("Create Process");
        createButton.addActionListener(e ->
        {
            String name = nameField.getText();
            if (name.isEmpty() || atField.getText().isEmpty() || btField.getText().isEmpty())
            {
                JOptionPane.showMessageDialog(null, "All fields must be filled.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            try
            {
                int AT = Integer.parseInt(atField.getText());
                int BT = Integer.parseInt(btField.getText());
                processes.add(new Process(total, name, AT, BT));
                model.addRow(new Object[]{total, name, AT, BT, "ready", "high"});
                total++;
                nameField.setText("");
                atField.setText("");
                btField.setText("");
            }
            catch (NumberFormatException ex)
            {
                JOptionPane.showMessageDialog(null, "Arrival Time and Burst Time must be integers.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        JButton destroyButton = createStyledButton("Destroy Process");
        destroyButton.addActionListener(e ->
        {
            String Id = JOptionPane.showInputDialog("Enter Process Id to Delete:");
            if (Id == null || Id.isEmpty())
            {
                JOptionPane.showMessageDialog(null, "Process Id cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            boolean found = processes.removeIf(p -> p.Id.equals(Id));
            if (found)
            {
                refreshTable();
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Process not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        JButton suspendButton = createStyledButton("Suspend Process");
        suspendButton.addActionListener(e -> updateProcessStatus("Enter Process Name to Suspend:", "suspend", "medium"));
        JButton resumeButton = createStyledButton("Resume Process");
        resumeButton.addActionListener(e -> updateProcessStatus("Enter Process Name to Resume:", "ready", "high"));
        JButton blockButton = createStyledButton("Block Process");
        blockButton.addActionListener(e -> updateProcessStatus("Enter Process Name to Block:", "block", "low"));
        JButton wakeupButton = createStyledButton("Wake Up Process");
        wakeupButton.addActionListener(e -> updateProcessStatus("Enter Process Name to Wake Up:", "ready", "high"));
        JButton dispatchButton = createStyledButton("Dispatch Process");
        dispatchButton.addActionListener(e ->
        {
            String Id = JOptionPane.showInputDialog("Enter Process Id to Dispatch:");
            boolean found = false;
            for (Process p : processes)
            {
                if (p.Id.equals(Id))
                {
                    p.dispatch();
                    found = true;
                }
            }
            if (found)
            {
                refreshTable();
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Process not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        JButton changePriorityButton = createStyledButton("Change Priority");
        changePriorityButton.addActionListener(e -> {
            String Id = JOptionPane.showInputDialog("Enter Process Name to Change Priority:");
            String newPriority = JOptionPane.showInputDialog("Enter New Priority:");
            boolean found = false;
            for (Process p : processes) {
                if (p.Id.equals(Id)) {
                    p.changePriority(newPriority);
                    found = true;
                }
            }
            if (found) {
                refreshTable();
            } else {
                JOptionPane.showMessageDialog(null, "Process not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        buttonPanel.add(createButton);
        buttonPanel.add(destroyButton);
        buttonPanel.add(suspendButton);
        buttonPanel.add(resumeButton);
        buttonPanel.add(blockButton);
        buttonPanel.add(wakeupButton);
        buttonPanel.add(dispatchButton);
        buttonPanel.add(changePriorityButton);

        JPanel inputAndButtonsPanel = new JPanel(new BorderLayout(15, 15));
        inputAndButtonsPanel.setBackground(new Color(45, 45, 45));
        inputAndButtonsPanel.add(inputPanel, BorderLayout.NORTH);
        inputAndButtonsPanel.add(buttonPanel, BorderLayout.CENTER);

        mainPanel.add(tablePanel, BorderLayout.CENTER);
        mainPanel.add(inputAndButtonsPanel, BorderLayout.EAST);

        processFrame.add(mainPanel);
        processFrame.setVisible(true);
    }

    private static JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("SansSerif", Font.BOLD, 14));
        button.setBackground(new Color(100, 149, 237));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        return button;
    }

    private static JLabel createStyledLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("SansSerif", Font.BOLD, 14));
        label.setForeground(Color.WHITE);
        return label;
    }

    private static void updateProcessStatus(String prompt, String status, String priority) {
        String Id = JOptionPane.showInputDialog(prompt);
        if (Id == null || Id.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Process name cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        boolean found = false;
        for (Process p : processes) {
            if (p.Id.equals(Id)) {
                p.status = status;
                p.priority = priority;
                found = true;
            }
        }
        if (found) {
            refreshTable();
        } else {
            JOptionPane.showMessageDialog(null, "Process not found.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void refreshTable() {
        model.setRowCount(0);
        for (Process p : processes) {
            model.addRow(new Object[]{p.pid, p.Id, p.AT, p.BT, p.status, p.priority});
        }
    }
}

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.LinkedList;
import java.util.Queue;

public class SchedulingManagement {

    private static Queue<Process> readyQueue = new LinkedList<>();
    private static Queue<Process> blockQueue = new LinkedList<>();

    public static void showScheduling(JFrame frame) {
        JFrame schedulingFrame = new JFrame("Scheduling Management");
        schedulingFrame.setSize(800, 600);
        schedulingFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel schedulingPanel = new JPanel(new GridBagLayout());
        schedulingPanel.setBackground(new Color(45, 45, 45));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(20, 20, 20, 20);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titleLabel = new JLabel("Scheduling Management", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        schedulingPanel.add(titleLabel, gbc);

        JButton fcfsButton = createButton("First Come First Serve (FCFS)");
        fcfsButton.addActionListener(e -> showFCFS(schedulingFrame));
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        schedulingPanel.add(fcfsButton, gbc);

        JButton rrButton = createButton("Round Robin");
        rrButton.addActionListener(e -> showRoundRobin(schedulingFrame));
        gbc.gridy = 2;
        schedulingPanel.add(rrButton, gbc);

        JButton backButton = createButton("Back");
        backButton.addActionListener(e -> {
            schedulingFrame.dispose();
            frame.setVisible(true);
        });
        gbc.gridy = 3;
        schedulingPanel.add(backButton, gbc);

        schedulingFrame.add(schedulingPanel);
        schedulingFrame.setVisible(true);
    }

    private static void showFCFS(JFrame frame) {
        frame.setVisible(false);
        JFrame fcfsFrame = new JFrame("First Come First Serve (FCFS)");
        fcfsFrame.setSize(800, 600);
        fcfsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(45, 45, 45));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField totalField = new JTextField(10);
        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel totalLabel = new JLabel("Enter total number of processes:");
        totalLabel.setForeground(Color.WHITE);
        panel.add(totalLabel, gbc);
        gbc.gridx = 1;
        panel.add(totalField, gbc);

        JButton calculateButton = createButton("Calculate FCFS");
        calculateButton.addActionListener(e -> {
            try {
                int total = Integer.parseInt(totalField.getText());
                if (total <= 0) {
                    throw new NumberFormatException();
                }
                fcfs(total);
                showAverageCalculator(total);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(fcfsFrame, "Please enter a valid positive number.");
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        panel.add(calculateButton, gbc);

        JButton backButton = createButton("Back");
        backButton.addActionListener(e -> {
            fcfsFrame.dispose();
            frame.setVisible(true);
        });
        gbc.gridy = 2;
        panel.add(backButton, gbc);

        fcfsFrame.add(panel);
        fcfsFrame.setVisible(true);
    }

    private static void showRoundRobin(JFrame frame) {
        frame.setVisible(false);
        JFrame rrFrame = new JFrame("Round Robin");
        rrFrame.setSize(800, 600);
        rrFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(45, 45, 45));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField processField = new JTextField(10);
        JTextField burstField = new JTextField(10);
        JTextField quantumField = new JTextField(10);

        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel processLabel = new JLabel("Enter process IDs (comma separated):");
        processLabel.setForeground(Color.WHITE);
        panel.add(processLabel, gbc);
        gbc.gridx = 1;
        panel.add(processField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        JLabel burstLabel = new JLabel("Enter burst times (comma separated):");
        burstLabel.setForeground(Color.WHITE);
        panel.add(burstLabel, gbc);
        gbc.gridx = 1;
        panel.add(burstField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        JLabel quantumLabel = new JLabel("Enter time quantum:");
        quantumLabel.setForeground(Color.WHITE);
        panel.add(quantumLabel, gbc);
        gbc.gridx = 1;
        panel.add(quantumField, gbc);

        JButton calculateButton = createButton("Calculate Round Robin");
        calculateButton.addActionListener(e -> {
            try {
                String[] processStr = processField.getText().split(",");
                String[] burstStr = burstField.getText().split(",");
                int quantum = Integer.parseInt(quantumField.getText());

                if (processStr.length != burstStr.length || quantum <= 0) {
                    throw new NumberFormatException();
                }

                int[] processes = new int[processStr.length];
                int[] burstTimes = new int[burstStr.length];

                for (int i = 0; i < processStr.length; i++) {
                    processes[i] = Integer.parseInt(processStr[i].trim());
                }
                for (int i = 0; i < burstStr.length; i++) {
                    burstTimes[i] = Integer.parseInt(burstStr[i].trim());
                }

                findavgTime(processes, burstTimes, quantum);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(rrFrame, "Please enter valid process IDs, burst times, and quantum.");
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        panel.add(calculateButton, gbc);

        JButton backButton = createButton("Back");
        backButton.addActionListener(e -> {
            rrFrame.dispose();
            frame.setVisible(true);
        });
        gbc.gridy = 4;
        panel.add(backButton, gbc);

        rrFrame.add(panel);
        rrFrame.setVisible(true);
    }

    private static void showAverageCalculator(int total) {
        JFrame avgFrame = new JFrame("Average Calculator");
        avgFrame.setSize(800, 600);
        avgFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(45, 45, 45));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JButton calculateButton = createButton("Calculate Average TAT, WT, RT");
        calculateButton.addActionListener(e -> {
            Avergecalculator(total);
            JOptionPane.showMessageDialog(avgFrame, "Average calculated.");
        });
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(calculateButton, gbc);

        JButton backButton = createButton("Back");
        backButton.addActionListener(e -> avgFrame.dispose());
        gbc.gridy = 1;
        panel.add(backButton, gbc);

        avgFrame.add(panel);
        avgFrame.setVisible(true);
    }

    private static void fcfs(int total) {
        System.out.println("FCFS with total processes: " + total);
    }

    private static void Avergecalculator(int total) {
        System.out.println("Average calculator for total processes: " + total);
    }

    private static void findavgTime(int[] processes, int[] burstTimes, int quantum) {
        System.out.println("Round Robin with quantum: " + quantum);
    }

    private static JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setPreferredSize(new Dimension(200, 40));
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setFont(new Font("Arial", Font.PLAIN, 18));
        return button;
    }
}

import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import static java.lang.Thread.sleep;
public class Main
{
    private static void showWelcomeScreen()
    {
        JFrame splashFrame = new JFrame();
        splashFrame.setUndecorated(true);
        splashFrame.setSize(600, 400);
        splashFrame.setLayout(new BorderLayout());
        splashFrame.setLocationRelativeTo(null);
        JLabel welcomeLabel = new JLabel("Welcome to Genetech OS", JLabel.CENTER);
        welcomeLabel.setFont(new Font("Ubuntu", Font.ITALIC, 36)); // Set heading to italic
        welcomeLabel.setForeground(new Color(0, 0, 0)); // Updated heading color
        splashFrame.add(welcomeLabel, BorderLayout.CENTER);
        splashFrame.getContentPane().setBackground(new Color(255, 84, 84)); // Background color for welcome screen
        splashFrame.setVisible(true);
        javax.swing.Timer splashTimer = new javax.swing.Timer(5000, e ->
        {
            splashFrame.dispose();
        });
        splashTimer.setRepeats(false);
        splashTimer.start();
    }
    public static void main(String[] args) throws InterruptedException
    {
        showWelcomeScreen();
        sleep(1000);

        JFrame frame = new JFrame("Genetech OS");
        frame.setBackground(new Color(255, 84, 84));
        frame.setSize(900, 700);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        JPanel panel = new JPanel(new BorderLayout())
        {
            @Override
            protected void paintComponent(Graphics g)
            {
                super.paintComponent(g);
            }
        };
        JLabel titleLabel = new JLabel("Genetech", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 36));
        titleLabel.setForeground(new Color(255, 215, 0));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(30, 0, 30, 0));
        JPanel mainMenuPanel = new JPanel(new GridBagLayout());
        mainMenuPanel.setBackground(new Color(255,84,84));
        mainMenuPanel.setOpaque(false);
        mainMenuPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        JButton processManagementButton = createButton("Process Management");
        processManagementButton.addActionListener(e -> ProcessManagement.showProcessManagement(frame));
        gbc.gridx = 0; gbc.gridy = 0;
        mainMenuPanel.add(processManagementButton, gbc);
        JButton memoryManagementButton = createButton("Memory Management");
        memoryManagementButton.addActionListener(e -> MemoryManagement.showMemoryManagement(frame));
        gbc.gridy = 1;
        mainMenuPanel.add(memoryManagementButton, gbc);
        JButton schedulingButton = createButton("Scheduling");
        schedulingButton.addActionListener(e -> SchedulingManagement.showScheduling(frame));
        gbc.gridy = 2;
        mainMenuPanel.add(schedulingButton, gbc);
        JButton ioOperationsButton = createButton("I/O Operations");
        ioOperationsButton.addActionListener(e -> IO_operation.showIOOperations(frame));
        gbc.gridy = 3;
        mainMenuPanel.add(ioOperationsButton, gbc);
        JButton pcbButton = createButton("Process Control Block");
        pcbButton.addActionListener(e -> PCBOperations.showPCBOperations(frame));
        gbc.gridy = 4;
        mainMenuPanel.add(pcbButton, gbc);
        JButton exitButton = createButton("Exit");
        exitButton.setBackground(new Color(255, 69, 58));
        exitButton.addActionListener(e -> System.exit(0));
        gbc.gridy = 5;
        mainMenuPanel.add(exitButton, gbc);
        panel.add(titleLabel, BorderLayout.NORTH);
        panel.add(mainMenuPanel, BorderLayout.CENTER);
        JPanel taskbarPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        taskbarPanel.setBackground(new Color(50, 50, 50));
        JLabel timeLabel = new JLabel();
        timeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        timeLabel.setForeground(Color.WHITE);
        taskbarPanel.add(timeLabel);
        panel.add(taskbarPanel, BorderLayout.SOUTH);
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                String currentTime = new SimpleDateFormat("hh:mm:ss a").format(new Date());
                timeLabel.setText(currentTime);
            }
        }, 0, 1000);
        frame.add(panel);
        frame.setVisible(true);
    }
    public static JButton createButton(String text)
    {
        JButton button = new JButton(text);
        button.setPreferredSize(new Dimension(300, 50));
        button.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        button.setBackground(new Color(7, 7, 7));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createLineBorder(new Color(70, 130, 180), 2));
        button.addMouseListener(new java.awt.event.MouseAdapter()
        {
            public void mouseEntered(java.awt.event.MouseEvent evt)
            {
                button.setBackground(new Color(135, 206, 250));

            }
            public void mouseExited(java.awt.event.MouseEvent evt)
            {
                button.setBackground(new Color(100, 149, 237));

            }
        });
        return button;
    }
}
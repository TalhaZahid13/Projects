const ROLE = {
    ADMIN : "ADMIN",
    GENERAL : "GENERAL"
}

export default ROLE
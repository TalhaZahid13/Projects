# Full-Stack-E-Commerce-MERN-APP
Full Stack E-Commerce MERN APP

![Alt text](Full%20Stack%20E-Commerce%20MERN%20App.png?raw=true "Title")

Backend .env file 

MONGODB_URI = 
TOKEN_SECRET_KEY = 
FRONTEND_URL

Frontend .env file

REACT_APP_CLOUD_NAME_CLOUDINARY = 

Image : https://drive.google.com/drive/folders/1KmY74OYniEodtOVAjNGJv4628HghRbcQ?usp=sharing
